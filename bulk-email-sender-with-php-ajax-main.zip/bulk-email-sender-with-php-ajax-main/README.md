# bulk-email-sender-with-php-ajax
This is a simple bulk email sender with php
